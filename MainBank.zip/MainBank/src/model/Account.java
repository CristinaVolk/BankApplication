package model;

public interface Account {
    
  public void deposit (float amount);
  
  public void withdraw (float amount);
    
}
