
package model.Exceptions;


public class InvalidAmountException extends Exception {
    public InvalidAmountException() {  
        System.out.println("Invalid amount for transaction");
    } 
   
}
