
package model.Exceptions;

public class AccNotFoundException extends Exception {

    public AccNotFoundException() {
    }


    public AccNotFoundException(String msg) {
        super(msg);
    }
}
