
package model.Exceptions;


public class BankException extends Exception {


    public BankException() {        
        System.out.println("The Bank doesn't exist\n");
    } 
}
