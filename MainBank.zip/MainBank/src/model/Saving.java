
package model;

public interface Saving {
    
    public void setInterest(float deposit);
    public double getInterest();
    public double addInterest(float balance, float amount);
    
    
}
