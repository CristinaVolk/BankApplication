
package model;

public interface Saving {
    
    public void setInterest(double deposit);
    public double getInterest();
    public double addInterest(double balance, double amount);
    
    
}
